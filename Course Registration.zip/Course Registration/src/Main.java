import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		
		ArrayList<Course> deserializedCourses;
		ArrayList<Student> deserializedStudents;
		
		File h = new File("Students.ser");
		if(h.exists() && !h.isDirectory()){
			try{
			      FileInputStream fis = new FileInputStream("Students.ser");
			   
			      ObjectInputStream ois = new ObjectInputStream(fis);
			      
			      deserializedStudents = (ArrayList<Student>)ois.readObject();
			      ois.close();
			      fis.close();
			    }
			    catch(IOException ioe) {
			       ioe.printStackTrace();
			       return;
			    }
				catch(ClassNotFoundException cnfe) {
			       cnfe.printStackTrace();
			       return;
			     }
			Data.setStudentArray(deserializedStudents);

		}
		File f = new File("Courses.ser");
		if(f.exists() && !f.isDirectory()) { 
			try{
		      FileInputStream fis = new FileInputStream("Courses.ser");
		      
		      ObjectInputStream ois = new ObjectInputStream(fis);
		      
		      deserializedCourses = (ArrayList<Course>)ois.readObject();
		      ois.close();
		      fis.close();
		    }
		    catch(IOException ioe) {
		       ioe.printStackTrace();
		       return;
		    }
			catch(ClassNotFoundException cnfe) {
		       cnfe.printStackTrace();
		       return;
		     }
			Data.setCourseArray(deserializedCourses);
		 }
		else{
			Scanner fileReader = new Scanner(new File("MyUniversityCourses.csv"));
			ArrayList<Course> csvCourses = new ArrayList();
			int counter = 0;
			while(fileReader.hasNextLine()){
				if(counter > 0){
						String[] courseArray = fileReader.nextLine().split(",");
						ArrayList<Student> listOfNames = new ArrayList<Student>();
						Course course = new Course(courseArray[0], courseArray[1],courseArray[2],courseArray[3],listOfNames,courseArray[5],courseArray[6],courseArray[7]);
						csvCourses.add(course);
					}
				else{
					fileReader.nextLine();
				}
				counter++;
				}
				Data.setCourseArray(csvCourses);
			}
		Menu.welcomeMessage();
		
		Menu.adminOrStudent();
	
		try {
			//FileOutput Stream writes data to a file
			File x = new File("Courses.ser");
			if(x.exists() && !x.isDirectory()){
				x.delete();
			}
			FileOutputStream fosCourse = new FileOutputStream("Courses.ser");
			
			
			//ObjectOutputStream writes objects to a stream (A sequence of data)
			ObjectOutputStream oosCourse = new ObjectOutputStream(fosCourse);
			
			//Writes the specific object to the OOS
			oosCourse.writeObject(Data.getCourses());
			
			//Close both streams
			oosCourse.close();
			
			fosCourse.close();
			
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
		
		try{	
			File x = new File("Students.ser");
			if(x.exists() && !x.isDirectory()){
				x.delete();
			}

			FileOutputStream fosStudent = new FileOutputStream("Students.ser");
			
			ObjectOutputStream oosStudent = new ObjectOutputStream(fosStudent);

			oosStudent.writeObject(Data.getStudents());
			oosStudent.close();
			
			fosStudent.close();
			
			System.out.println("Serialization complete");
		} 
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
		
	}


