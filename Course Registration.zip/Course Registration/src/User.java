import java.io.Serializable;
import java.util.ArrayList;

public abstract class User implements Serializable{
	
	private String username;
	private String password;
	private String fName;
	private String lName;
	private ArrayList<Course> courses = new ArrayList<Course>();
	
	public User(String user, String pwd, String fName, String lName){
		this.username = user;
		this.password = pwd;
		this.fName = fName;
		this.lName = lName;
	}
	
	public User(){
		
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}
	
	public ArrayList<Course> getCourseArray(){
		return courses;
	}

}
