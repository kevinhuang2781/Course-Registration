import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
	
	
	
	public static void welcomeMessage(){
		System.out.printf("Welcome to the Course Registration App.\n");
	}
	
	public static void adminOrStudent(){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Are you an admin or a student?");
		System.out.println("Type exit to exit out of the app.");
		String input = inputReader.nextLine().toLowerCase();
		if (input.equals("admin")){
			login(Data.getAdmin());
		}
		else if(input.equals("student")){
			login();
		}
		else if(input.toLowerCase().equals("exit")){
			fullExit();
		}
		else{
			adminOrStudent();
		}

	}
	
	public static void login(Admin admin){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Username: ");
		String user = inputReader.nextLine();
		System.out.println("Password: ");
		String pwd = inputReader.nextLine();
		
		if(admin.getUsername().equals(user) && admin.getPassword().equals(pwd)){
			adminMenu(admin);
		}
		else{
			login(admin);
		}
		
	}
	public static void login(){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Username: ");
		String user = inputReader.nextLine();
		System.out.println("Password: ");
		String pwd = inputReader.nextLine();
		
		boolean correct = false;
		
		for(int i = 0; i < Data.getStudents().size(); i++){
			//System.out.println(Data.getStudents().get(2).getUsername());
			if(Data.getStudents().get(i).getUsername().equals(user) && Data.getStudents().get(i).getPassword().equals(pwd)){
				studentMenu(Data.getStudents().get(i));
				correct = true;
			}
		}
		if(correct == false){
			login();
		}
	}
	
	public static void adminMenu(Admin admin){
		Scanner inputReader = new Scanner(System.in);
		enterNumber();
		System.out.println("1. Course Management");
		System.out.println("2. Reports");
		System.out.println("3. Main Menu");
		String command = inputReader.nextLine();
		switch (command){
			case "1": courseManagement(admin);
			break;
			case "2": reports(admin);
			break;
			case "3": mainMenu();
			break;
			default: System.out.println("Invalid Command"); adminMenu(admin);
		}
			
	}
	
	public static void courseManagement(Admin admin){
		Scanner inputReader = new Scanner(System.in);
		enterNumber();
		System.out.println("1. Create a new course");
		System.out.println("2. Delete a course");
		System.out.println("3. Edit a course");
		System.out.println("4. Display information for a given course");
		System.out.println("5. Register a student");
		System.out.println("6. Back");
		System.out.println("7. Main Menu");
		String command = inputReader.nextLine();
		switch (command){
			case "1": createCoursePrompt(admin); 
			break;
			case "2": deleteCoursePrompt(admin);
			break;
			case "3": editCoursePrompt(admin);
			break;
			case "4": displayInfoPrompt(admin); 
			break;
			case "5": registerStudentPrompt(admin); 
			break;
			case "6": adminMenu(admin);
			break;
			case "7": mainMenu(); 
			break;
			default: courseManagement(admin);
		}
			
	}
	
	public static void createCoursePrompt(Admin admin){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Please enter the name of the course:");
		String name = inputReader.nextLine();
		System.out.println("Please enter the course ID:");
		String ID = inputReader.nextLine();
		System.out.println("Please enter the maximum number of students allowed for this course:");
		String maxStudents = inputReader.nextLine();
		System.out.println("Please enter the name of the instructor:");
		String instructor = inputReader.nextLine();
		System.out.println("Please enter the section number:");
		String sectionNumber = inputReader.nextLine();
		System.out.println("Please enter the location of the class:");
		String location = inputReader.nextLine();
		
		ArrayList<Student> listOfNames = new ArrayList<Student>();
			
		admin.createCourse(name, ID, maxStudents, "0", listOfNames, instructor, sectionNumber, location);
		
		courseManagement(admin);
	
	}
	
	public static void deleteCoursePrompt(Admin admin){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Which course would you like to delete?");
		for(int i = 0; i < admin.getCourseArray().size(); i++){
			System.out.println((i + 1) + admin.getCourseArray().get(i).getCourseName());
		}
		int deleteCourseIndex = Integer.parseInt(inputReader.nextLine()) - 1;		
		admin.deleteCourse(deleteCourseIndex);
		
		courseManagement(admin);
	}
	
	public static void editCoursePrompt(Admin admin){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Which course would you like to edit?");
		for(int i = 0; i < admin.getCourseArray().size(); i++){
			System.out.println((i + 1) + admin.getCourseArray().get(i).getCourseName());
		}
		int editCourseIndex = Integer.parseInt(inputReader.nextLine()) - 1;	
		
		System.out.println("Which property would you like to change?");
		System.out.println("1. Maxmimum students");
		System.out.println("2. Current students");
		System.out.println("3. Instructor");
		System.out.println("4. Section Number");
		System.out.println("5. Location");
		String command = inputReader.nextLine();
		int property = Integer.parseInt(command);
		
		System.out.println("What would you like to change the property to?");
		String newValue = inputReader.nextLine();
		admin.editCourse(editCourseIndex, property, newValue);
		
		courseManagement(admin);
	}
	
	public static void displayInfoPrompt(Admin admin){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Please enter the course name of the course you would like to see:");
		String name = inputReader.nextLine();
		System.out.println("Please enter the section number of the course you would like to see:");
		String sectionNum = inputReader.nextLine();
		admin.displayCourseInfo(name, sectionNum);
		
		System.out.println("\nPlease hit enter when done to go back to the admin menu");
		String entered = inputReader.nextLine();
		courseManagement(admin);
	}
	
	public static void registerStudentPrompt(Admin admin){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Please enter the username of the student");
		String user = inputReader.nextLine();
		System.out.println("Please enter the password of the student");
		String pwd = inputReader.nextLine();
		System.out.println("Please enter the first name of the student");
		String fName = inputReader.nextLine();
		System.out.println("Please enter the last name of the student");
		String lName = inputReader.nextLine();
		
		admin.registerStudent(user, pwd, fName, lName);
		
		courseManagement(admin);
	}
	
	public static void reports(Admin admin){
			Scanner inputReader = new Scanner(System.in);
			enterNumber();
			System.out.println("1. View all courses");
			System.out.println("2. View full courses");
			System.out.println("3. Write to a file the list of courses that are full");
			System.out.println("4. View the names of students registered in a specific course");
			System.out.println("5. View the list of courses that a given student is registered in");
			System.out.println("6. Sort courses based on current number of students registered");
			System.out.println("7. Back");
			System.out.println("8. Main Menu");
			String command = inputReader.nextLine();
			switch (command){
				case "1": viewAllCoursesPrompt(admin);
				break;
				case "2": viewFullCoursesPrompt(admin);
				break;
				case "3": admin.writeToFile(); reports(admin);
				break;
				case "4": viewRegisteredStudentsPrompt(admin);
				break;
				case "5": viewStudentsCourses(admin);
				break;
				case "6": sortCoursesPrompt(admin);
				break;
				case "7": adminMenu(admin);
				break;
				case "8": mainMenu();
				break;
				default: reports(admin);
			}
	}
	
	public static void viewAllCoursesPrompt(Admin admin){
		admin.viewAllCourses();
		Scanner inputReader = new Scanner(System.in);
		System.out.println("\nPlease hit enter when done to go back to the admin menu");
		String entered = inputReader.nextLine();
		reports(admin);
	}
	
	public static void viewFullCoursesPrompt(Admin admin){
		admin.viewFullCourses();
		Scanner inputReader = new Scanner(System.in);
		System.out.println("\nPlease hit enter when done to go back to the admin menu");
		String entered = inputReader.nextLine();
		reports(admin);
	}

	public static void viewRegisteredStudentsPrompt(Admin admin){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Please enter the course name:");
		String courseName = inputReader.nextLine();
		System.out.println("Please enter the section number:");
		String sectionNum = inputReader.nextLine();
		if(!admin.getIsValid()){
			System.out.println("No courses with the matching information.");
			admin.setIsValid(true);
			reports(admin);
		}
		
		System.out.println("\nPlease hit enter when done to go back to the admin menu");
		String entered = inputReader.nextLine();
		reports(admin);
	}
	
	public static void viewStudentsCourses(Admin admin){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Please enter the first name of the desired student:");
		String fName = inputReader.nextLine();
		System.out.println("Please enter the last name of the desired student:");
		String lName = inputReader.nextLine();
		admin.viewStudentCourses(fName, lName);

		System.out.println("\nPlease hit enter when done to go back to the admin menu");
		String entered = inputReader.nextLine();
		reports(admin);
	}
	
	public static void sortCoursesPrompt(Admin admin){
		admin.sortCourses();
		Scanner inputReader = new Scanner(System.in);
		System.out.println("\nPlease hit enter when done to go back to the admin menu");
		String entered = inputReader.nextLine();
		reports(admin);
		
	}
	
	public static void studentMenu(Student student){
		Scanner inputReader = new Scanner(System.in);
		enterNumber();
		System.out.println("1. Course Management");
		System.out.println("2. Main Menu");
		String command = inputReader.nextLine();
		switch (command){
			case "1": courseManagement(student);
				break;
			case "2": mainMenu();
				break;
			default: studentMenu(student);
		}
	}

	public static void courseManagement(Student student){
		Scanner inputReader = new Scanner(System.in);
		enterNumber();
		System.out.println("1. View all courses");
		System.out.println("2. View all courses that are not full");
		System.out.println("3. Register in a course");
		System.out.println("4. Withdraw from a course");
		System.out.println("5. View your courses");
		System.out.println("6. Main Menu");
		String command = inputReader.nextLine();
		switch (command){
			case "1": viewAllCoursesPrompt(student);
				break;
			case "2": viewNonFullCoursesPrompt(student);
				break;
			case "3": registerPrompt(student); 
				break;	
			case "4": withdrawPrompt(student);
				break;	
			case "5": viewCurrentCoursesPrompt(student);
			break;	
			case "6": mainMenu();
				break;	
			default: courseManagement(student);
		}
	}
	
	public static void viewAllCoursesPrompt(Student student){
		student.viewAllCourses();
		Scanner inputReader = new Scanner(System.in);
		System.out.println("\nPlease hit enter when done to go back to the student menu");
		String entered = inputReader.nextLine();
		courseManagement(student);
	}
	
	public static void viewNonFullCoursesPrompt(Student student){
		student.viewNonFullCourses();
		Scanner inputReader = new Scanner(System.in);
		System.out.println("\nPlease hit enter when done to go back to the student menu");
		String entered = inputReader.nextLine();
		courseManagement(student);
	}
	
	public static void registerPrompt(Student student){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Please enter your first name:");
		String fName = inputReader.nextLine();
		System.out.println("Please enter your last name:");
		String lName = inputReader.nextLine();
		System.out.println("Please enter the name of the course:");
		String courseName = inputReader.nextLine();
		System.out.println("Please enter the desired section:");
		String sectionNum = inputReader.nextLine();
		
		student.register(courseName, sectionNum, student);
		System.out.println("You are registered!");
		courseManagement(student);
	}
	
	public static void withdrawPrompt(Student student){
		Scanner inputReader = new Scanner(System.in);
		System.out.println("Please enter your first name:");
		String fName = inputReader.nextLine();
		System.out.println("Please enter your last name:");
		String lName = inputReader.nextLine();
		System.out.println("Please enter the name of the course:");
		String courseName = inputReader.nextLine();
		
		student.withdraw(courseName, student);
		
		System.out.println("You have been removed from the course!");
		courseManagement(student);
	}
	
	public static void viewCurrentCoursesPrompt(Student student){
		student.viewCurrentCourses(student);
		Scanner inputReader = new Scanner(System.in);
		System.out.println("\nPlease hit enter when done to go back to the student menu");
		String entered = inputReader.nextLine();
		courseManagement(student);
	}
	
	public static void mainMenu(){
		System.out.println("You have logged out.");
		adminOrStudent();
	}
	
	public static void fullExit(){
		System.out.println("You have exit the app.");
	}
	
	public static void enterNumber(){
		System.out.println("Please enter the number of the command you wish to execute:");
	}
}


