import java.util.ArrayList;

public interface AdminInterface {

	//Course Management
	public void createCourse(String name, String ID, String maxStudents, String currentStudents, ArrayList<Student> listOfNames, String instructor, String sectionNumber, String location);

	public void deleteCourse(int courseIndex);
	
	public void editCourse(int courseIndex, int property, String newValue);
	
	public void displayCourseInfo(String courseName, String sectionNum);
	
	public void registerStudent(String user, String pwd, String fName, String lName);
	
	public void exit();
	
	//Reports
	public void viewAllCourses();
	
	public void viewFullCourses();
	
	public void writeToFile();
	
	public void viewStudentNames(String course, String sectionNum);
	
	public void viewStudentCourses(String fName, String lName);
	
	public void sortCourses();
	
}
