import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class Data implements Serializable{

	static Admin admin = new Admin("Admin", "Admin001", "Kevin", "Huang");
	
	private static ArrayList<Student> students = new ArrayList<Student>();

	private static ArrayList<Course> courses = new ArrayList<Course>();
	
	public boolean correctLoginInfo(String user, String pwd){
		for(int i = 0; i < students.size(); i++){
			if(user.equals(students.get(i).getUsername()) && pwd.equals(students.get(i).getPassword())){
				return true;
			}
			else if(user.equals(admin.getUsername()) && pwd.equals(admin.getPassword())){
				return true;
				}
			}	
		
		return false;	
	}
	
	public static Admin getAdmin(){
		return admin;
	}
	
	public static ArrayList<Student> getStudents(){
		return students;
	}
	public static void addStudent(Student student){
		students.add(student);
		if(students.get(0) == null){
			students.remove(0);
		}
	}
	
	public static ArrayList<Course> getCourses(){
		return courses;
	}
	public static void addCourse(Course course){
		courses.add(course);
	}
	
	public static void setCourseArray(ArrayList<Course> courses){
		Data.courses = courses;
	}
	public static void setStudentArray(ArrayList<Student> students){
		Data.students = students;
	}
	
	public static void removeElement(int index){
		courses.remove(index);
	}
	
}
