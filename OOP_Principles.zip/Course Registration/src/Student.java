import java.io.Serializable;
import java.util.ArrayList;

public class Student extends User implements StudentInterface, Serializable {
	
	private ArrayList<Course> courses = new ArrayList<Course>();
	
	public Student(String user, String pwd, String fName, String lName) {
		super(user, pwd, fName, lName);
	}
	public Student() {
		super();
	}

	@Override
	public void viewAllCourses() {
		for(int i = 0; i < Data.getCourses().size(); i++){
				System.out.printf("%20s ", Data.getCourses().get(i).getCourseName());
				System.out.printf(" %s %20s %15s", Data.getCourses().get(i).getSectionNumber(), Data.getCourses().get(i).getInstructor(), Data.getCourses().get(i).getLocation());
				System.out.printf("%3s %3s\n", Data.getCourses().get(i).getCurrentStudents(), Data.getCourses().get(i).getMaxStudents());
			}
	}

	@Override
	public void viewNonFullCourses() {
		for(int i = 0; i < Data.getCourses().size(); i++){
			if(Integer.parseInt(Data.getCourses().get(i).getCurrentStudents().trim()) < Integer.parseInt(Data.getCourses().get(i).getMaxStudents().trim())){
				System.out.printf("%20s ", Data.getCourses().get(i).getCourseName());
				System.out.printf(" %s %20s %15s", Data.getCourses().get(i).getSectionNumber(), Data.getCourses().get(i).getInstructor(), Data.getCourses().get(i).getLocation());
				System.out.printf("%3s %3s\n", Data.getCourses().get(i).getCurrentStudents(), Data.getCourses().get(i).getMaxStudents());
			}
		}
	}

	@Override
	public void register(String courseName, String sectionNum, Student student) {
		for(int i = 0; i < Data.getCourses().size(); i++){
			if(Data.getCourses().get(i).getCourseName().equals(courseName) && Data.getCourses().get(i).getSectionNumber().equals(sectionNum)){
				Data.getCourses().get(i).addStudentName(student);
				courses.add(Data.getCourses().get(i));
			}
		}
		
	}

	@Override
	public void withdraw(String courseName, Student student) {
		for(int i = 0; i < Data.getCourses().size(); i++){
			if(courseName.equals(Data.getCourses().get(i).getCourseName())){
				Data.getCourses().get(i).removeStudent(student);
				courses.remove(Data.getCourses().get(i));
			}
		}		
	}

	@Override
	public void viewCurrentCourses(Student student) {
		for(int i = 0; i < courses.size(); i++){
				System.out.println(courses.get(i).getCourseName() + "  " + courses.get(i).getSectionNumber());
		}
		
	}

	@Override
	public void exit() {
	}
	
	public static String toString(ArrayList<Course> list){
		String string = "";
		for(int i = 0; i < list.size(); i++){
			if(i < list.size() - 1){
				string += list.get(i).getCourseName() + list.get(i).getSectionNumber() + ",";
			}
		}
		return string;
	}
	
	public ArrayList<Course> getCourseArray(){
		return courses;
	}

}
