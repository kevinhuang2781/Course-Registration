
public interface StudentInterface {

	public void viewAllCourses();
	
	public void viewNonFullCourses();
	
	public void register(String courseName, String sectionNum, Student student);
	
	public void withdraw(String courseName, Student student);
	
	public void viewCurrentCourses(Student student);
	
	public void exit();
}
