import java.io.Serializable;
import java.util.ArrayList;

public class Course extends Data implements Comparable<Course>, Serializable{
	
	private String courseName;
	
	private String courseID;
	
	private String maxStudents;
	
	private String currentStudents;
	
	private ArrayList<Student> listOfNames = new ArrayList<Student>();
	
	private String instructor;
	
	private String sectionNumber;
	
	private String location;
	
	
	public Course(String name, String ID, String maxStudents, String currentStudents, ArrayList<Student> listOfNames, String instructor, String sectionNumber, String location){
		this.courseName = name;
		this.courseID = ID;
		this.maxStudents = maxStudents;
		this.currentStudents = currentStudents;
		this.listOfNames = listOfNames;
		this.instructor = instructor;
		this.sectionNumber = sectionNumber;
		this.location = location;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseID() {
		return courseID;
	}

	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}

	public String getMaxStudents() {
		return maxStudents;
	}

	public void setMaxStudents(String maxStudents) {
		this.maxStudents = maxStudents;
	}

	public String getCurrentStudents() {
		return currentStudents;
	}

	public void setCurrentStudents(String currentStudents) {
		this.currentStudents = currentStudents;
	}

	public ArrayList<Student> getListOfNames() {
		return listOfNames;
	}

	public void addStudentName(Student student) {
		this.listOfNames.add(student);
		int current = Integer.parseInt(this.currentStudents) + 1;
		this.currentStudents = Integer.toString(current);
	}

	public String getInstructor() {
		return instructor;
	}

	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}

	public String getSectionNumber() {
		return sectionNumber;
	}

	public void setSectionNumber(String sectionNumber) {
		this.sectionNumber = sectionNumber;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	
	public static String toString(ArrayList<Student> list){
		String string = "";
		for(int i = 0; i < list.size(); i++){
			string += list.get(i).getfName() + list.get(i).getlName();
		}
		return string;
	}
	
	public boolean isInCourse(Student student){
		for(int i = 0; i < this.listOfNames.size(); i++){
			if(student.getfName().equals(this.listOfNames.get(i).getfName()) && student.getlName().equals(this.listOfNames.get(i).getlName())){
				return true;
			}
		}
		return false;
	}
	
	public void removeStudent(Student student){
		for(int i = 0; i < this.listOfNames.size(); i++){
			if(student.getfName().equals(this.listOfNames.get(i).getfName()) && student.getlName().equals(this.listOfNames.get(i).getlName())){
				this.listOfNames.remove(i);
				int current = Integer.parseInt(this.currentStudents) - 1;
				this.currentStudents = Integer.toString(current);
			}
		}
	}
	
	
	
	@Override
	public int compareTo(Course o) {
		if(Integer.parseInt(this.getCurrentStudents()) > Integer.parseInt(o.getCurrentStudents())){
			return 1;
		}
		else if(Integer.parseInt(this.getCurrentStudents()) < Integer.parseInt(o.getCurrentStudents())){
			return -1;
		}
		else{
			return 0;
		}
	}

}
