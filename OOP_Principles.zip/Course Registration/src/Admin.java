import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Scanner;

public class Admin extends User implements AdminInterface{
	
	private boolean isValid = true;
	
	public Admin(String user, String pwd, String fName, String lName){
		super(user, pwd, fName, lName);
	}
	
	public void createCourse(String name, String ID, String maxStudents, String currentStudents, ArrayList<Student> listOfNames, String instructor, String sectionNumber, String location) {
		Course course = new Course(name, ID, maxStudents, currentStudents, listOfNames, instructor, sectionNumber, location);
		Data.addCourse(course);
		System.out.println("Course added!");
	}

	public void deleteCourse(int courseIndex) {
		Data.removeElement(courseIndex);
		System.out.println("Course deleted");
	}
	
	public void editCourse(int courseIndex, int property, String newValue) {
		switch(property){
			case 1: Data.getCourses().get(courseIndex).setMaxStudents(newValue);
				break;
			case 2: Data.getCourses().get(courseIndex).setCurrentStudents(newValue);
				break;
			case 3: Data.getCourses().get(courseIndex).setInstructor(newValue);
				break;
			case 4: Data.getCourses().get(courseIndex).setSectionNumber(newValue);
				break;
			case 5: Data.getCourses().get(courseIndex).setLocation(newValue);
				break;
		}
	}
	
	public void displayCourseInfo(String courseName, String sectionNum) {
		for(int i = 0; i < Data.getCourses().size(); i++){
			if(courseName.equals(Data.getCourses().get(i).getCourseName()) && sectionNum.equals(Data.getCourses().get(i).getSectionNumber())){
				System.out.printf("%s %s %s %s %s %s %s %s", Data.getCourses().get(i).getCourseName(), Data.getCourses().get(i).getCourseID(), Data.getCourses().get(i).getMaxStudents(), Data.getCourses().get(i).getCurrentStudents(), Data.getCourses().get(i).getListOfNames(), Data.getCourses().get(i).getInstructor(), Data.getCourses().get(i).getSectionNumber(), Data.getCourses().get(i).getLocation());
			}
		}
	}
	
	public void registerStudent(String user, String pwd, String fName, String lName) {
		Student student = new Student(user, pwd, fName, lName);
		Data.addStudent(student);
		System.out.println("Student Registered.");
	}
	
	public void exit() {
	}

	@Override
	public void viewAllCourses() {
		for(int i = 0; i < Data.getCourses().size(); i++){
				System.out.printf("%30s ", Data.getCourses().get(i).getCourseName());
				System.out.printf(" %s ", Data.getCourses().get(i).getSectionNumber());
				System.out.printf("%3s %3s ", Data.getCourses().get(i).getCurrentStudents(), Data.getCourses().get(i).getMaxStudents());
				for(int j = 0; j < Data.getCourses().get(i).getListOfNames().size(); j++){
					System.out.printf("%15s ", Data.getCourses().get(i).getListOfNames().get(j).getUsername());
				}
				System.out.printf("%50s\n", Course.toString(Data.getCourses().get(i).getListOfNames()));
				
			}
	}

	@Override
	public void viewFullCourses() {
		for(int i = 0; i < Data.getCourses().size(); i++){
				if(Data.getCourses().get(i).getCurrentStudents().equals(Data.getCourses().get(i).getMaxStudents())){
					System.out.printf("%50s ", Course.toString(Data.getCourses().get(i).getListOfNames()));
					for(int k = 0; k < Data.getCourses().get(i).getListOfNames().size(); k++){
						System.out.printf("%15s ", Data.getCourses().get(i).getListOfNames().get(k).getUsername());
					}
					System.out.printf("%3s %3s ", Data.getCourses().get(i).getCurrentStudents(), Data.getCourses().get(i).getMaxStudents());
					System.out.printf("%50s\n", Course.toString(Data.getCourses().get(i).getListOfNames()));
				}
		}
	}

	@Override
	public void writeToFile() {
		PrintWriter writer = null;
		try {
			writer = new PrintWriter("fullCourses.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		for(int i = 0; i < Data.getCourses().size(); i++){
				if(Data.getCourses().get(i).getCurrentStudents().equals(Data.getCourses().get(i).getMaxStudents())){
					writer.printf("%50s ", Course.toString(Data.getCourses().get(i).getListOfNames()));
					for(int k = 0; k < Data.getCourses().get(i).getListOfNames().size(); k++){
						writer.printf("%15s ", Data.getCourses().get(i).getListOfNames().get(k).getUsername());
					}
					writer.printf("%3s %3s", Data.getCourses().get(i).getCurrentStudents(), Data.getCourses().get(i).getMaxStudents());
			}
		}
		writer.close();
		
	}

	@Override
	public void viewStudentNames(String courseName, String sectionNum) {
		for(int i = 0; i < Data.getCourses().size(); i++){
			if(Data.getCourses().get(i).getCourseName().equals(courseName) && Data.getCourses().get(i).getSectionNumber().equals(sectionNum)){
				System.out.printf("%s\n", Course.toString(Data.getCourses().get(i).getListOfNames()));
			}
			else{
				isValid = false;
			}
		}
	}

	@Override
	public void viewStudentCourses(String fName, String lName) {
		for(int i = 0; i < Data.getStudents().size(); i++){
			if(fName.equals(Data.getStudents().get(i).getfName()) && lName.equals(Data.getStudents().get(i).getlName())){
				Data.getStudents().get(i).viewCurrentCourses(Data.getStudents().get(i));
			}
		}
		
	}

	@Override
	public void sortCourses() {
		for(int i = 0; i < Data.getCourses().size() - 1; i++){
			for(int j = 0; j < Data.getCourses().size() - i - 1; j++){
			if(Data.getCourses().get(j).getCurrentStudents().compareTo(Data.getCourses().get(j + 1).getCurrentStudents()) < 0){
				swap(j, j+1, Data.getCourses());
			 }
			}
		}
		
		viewAllCourses();
	}
	
	public ArrayList<Course> getCourseArray(){
		return Data.getCourses();
	}
	
	public boolean getIsValid(){
		return isValid;
	}
	public void setIsValid(boolean isValid){
		this.isValid = isValid;
	}
	
	public void swap(int i, int j, ArrayList<Course> course){
		Course temp = course.get(i);
		course.set(i, course.get(j));
		course.set(j, temp);
	}

	

}
