
public class Arrays_2 {

	public static String s = "Other entries include a historic district in Charlottesville Virginia cut-flower greenhouse complex";
	public static String[] strings = s.split("\\s+");
			
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(f(strings));

	}
	
	/**
	 * This method returns the shortest string in each set of 3 strings within a sentence.
	 * @param s The array representing the sentence in question.
	 * @return A string containing all of the short strings.
	 */
	public static String f(String[] s){
		String shortString = ""; //to be returned
		int shortest = -1; //Set shortest index to an impossible value at first
		for(int i = 0; i < s.length; i++){ 
			if((i + 1) % 3 == 0){ //If we are at a multiple of 3
				int count = i; 
				while(count - 1 >= i - 2){ //Cycle through subarray containing the 3 strings in question
					if(shortest < i-2){ //Since shortest is still -1 or the previous value, we set it to where the index we are currently at.
						shortest = count;
					}	
					if(s[shortest].length() > s[count - 1].length()){ //Determine the shortest index
						shortest = count - 1;
					}
					count--;
				}
				shortString += s[shortest] + " "; //add the shortest string to shortString
			}
		}
		return shortString;
	}
}
