
public class Recursion_3 {

	public static void main(String[] args) {
		// Test method
		if(isPalindrome("kayak")){
			System.out.println("true");
		}
		else{
			System.out.println("false");
		}
		
		if(isPalindrome("kevin")){
			System.out.println("true");
		}
		else{
			System.out.println("false");
		}
	}
	
	//Recursive method to reverse a string
	public static String reverse(String s){
		if(s.length() == 1){ //Base Case, if the string is left with one character, return that character.
			return s;
		}
		else{
			//Add last character with the next last character and repeat until base case.
			return s.substring(s.length()-1) + reverse(s.substring(0, s.length() - 1));	 	
		}
	}
	
	//Return true if the reverse of the word is equal to the word. Else return false.
	public static boolean isPalindrome(String s){
		if(reverse(s).toLowerCase().equals(s.toLowerCase())){
			return true;
		}
		return false;
		
	}

}
