
public class QuickSort extends SortingHelper{

	public static void main(String[] args) {
		int[] arr = {4, 77, 98, 30, 20, 50, 77, 22, 49, 2};
		quickSort(arr, 0, arr.length-1);
		//printArray(arr);

	}
	
	//Quick Sort chooses a pivot point and makes sure every element to the left are smaller and all elements to the right
	//are larger. The run time is O(nlog(n)). 
	public static void quickSort(int[] arr, int start, int end){
		if(start >= end){
			return;
		}
		else{
			printArray(arr);
			int pivot = partition(arr, start, end);
			quickSort(arr, start, pivot - 1);
			quickSort(arr, pivot + 1, end);
		}
	}
	
	public static int partition(int[] arr, int start, int end){
		//We are setting the arbitrary pivot point to the end for simplicity.
		int pivot = end;
		int i = start - 1;
		int j = start;

		while(j < end){
			//When we hit an element that is smaller than the pivot, we want to swap it with a previous larger value.
			if(arr[j] < arr[pivot]){	
				i++;
				SortingHelper.swap(arr, i , j);
				
			}
			j++;
		}
		
		//i + 1 is the index of where the pivot should belong since all elements to the left will be smaller,
		//and all elements to the right will be larger.
		swap(arr, ++i, pivot);
		return i;
	}

}
