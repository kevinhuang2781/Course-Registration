
public class NonRecursiveBubbleSort extends SortingHelper{

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printArray(bubbleSortNR(ARR));
	}
	
	//Move largest unsorted element to the end
	public static int[] bubbleSortNR(int[] arr){
		for(int i = 0; i < arr.length - 1; i++){
			for(int j = 0; j < arr.length - i - 1; j++){
				//Compare side by side values
				if(arr[j] > arr[j+1]){
					swap(arr, j , j+1);
				}
			}
		}
		return arr;
	}
	
	

}
