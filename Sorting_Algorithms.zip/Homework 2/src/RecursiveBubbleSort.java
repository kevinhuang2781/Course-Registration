
public class RecursiveBubbleSort extends SortingHelper{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printArray(bubbleSortR(ARR, ARR.length));
	}
	
	//Move largest unsorted element to end of array
	public static int[] bubbleSortR(int[] arr, int n){
		if(n == 0){
			return arr;
		}
		else{
			for(int i = 0; i < arr.length - 1; i++){
				bubbleSortR(arr, n - 1);
				//Compare side by side values, if left>right swap
				if(arr[i] > arr[i+1]){
					swap(arr, i, i+1);
				}
			}
			return arr;
		}
	}

}
