
public class Recursion_2 {

	public static void main(String[] args) {
		// Test different numbers
		System.out.println(findBinaryZeroes(20, getLargestPower(20)));
		System.out.println(findBinaryZeroes(170, getLargestPower(170)));
		System.out.println(findBinaryZeroes(464, getLargestPower(464)));
	}
	
	/**
	 * Recursive method that finds the amount of zeroes are in the binary representation of a number
	 * @param n The number in question
	 * @param power The current power of 2 
	 * @return The amount of zeroes
	 */
	public static int findBinaryZeroes(int n, int power){
		
		//Base Case: If the power is at 0, then 2^0 will be 1 if the remainder is 1 and 0 if the remainder is 0.
		//If 2^0 is 1, then there is no 0 in the 2^0th place.
		if(power == 0){
			if(n == 0){
				return 1;
			}
			if(n == 1){
				return 0;
			}
		}
		//If 2^power is less than n then there is a 1 in that place of the binary digit.
		if(Math.pow(2, power) <= n){
			//We subtract n by that number and reduce the power by one.
			return findBinaryZeroes((int)(n - Math.pow(2, power)), power - 1);
		}
		else{
			//If 2^power is not less than n, then there is a 0 in that place of the binary digit.
			//We add 1 to the amount of zeroes and reduce the power by 1.
			return 1 + findBinaryZeroes(n, power - 1);
		}
	}
	
	public static int getLargestPower(int n){
		int power = 0;
		
		while(Math.pow(2, power) <= n){
			power++;
		}
	
		return power - 1;
	}
}