
public class Arrays_1 {

	public static void main(String[] args) {
		//Test the method
		System.out.println(isReversed("google", "elgoog"));
		System.out.println(isReversed("google", "google"));

	}
	
	/**
	 * This method returns 1 is one string input is the reverse of the other string input. If not, 0 is returned.
	 * @param s1 First String
	 * @param s2 Second String
	 * @return True or false as expressed by 1 and 0.
	 */
	public static int isReversed(String s1, String s2){
		String reversed = "";
		for(int i = 0; i < s2.length(); i++){
			reversed = s2.substring(i, i+1) + reversed;  //create the reversed word.
		}
		if(s1.toLowerCase().equals(reversed.toLowerCase())){ //check if word1 and the reverse of word2 are equal.
			return 1;
		}
		return 0;
	}
	
}
