/**
 * A class containing useful functions for various sorting classes.
 * @author kevinhuang
 */
public class SortingHelper {

	public static final int[] ARR = {4, 77, 98, 30, 20, 50, 77, 22, 49, 2};
	
	public static void swap(int[] arr, int x, int y){
		int temp = arr[x];
		arr[x] = arr[y];
		arr[y] = temp;
	}
	
	public static void printArray(int[] arr){
		for(int i = 0; i < arr.length; i++){
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}
}
