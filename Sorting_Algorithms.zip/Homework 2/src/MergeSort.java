
public class MergeSort extends SortingHelper{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {4, 77, 98, 30, 20, 50, 77, 22, 49, 2};
		mergeSort(arr, 0, arr.length-1);
		printArray(arr);

	}
	
	public static void mergeSort(int[] arr, int left, int right){		
		if(left == right){
			return;
		}
		int mid = (left + right)/2;
		mergeSort(arr, left, mid);
		mergeSort(arr, mid + 1, right);
		merge(arr, left, mid, right);
	}

	public static int[] merge(int[] arr, int left, int mid, int right){
		//Create 2 arrays to be merged
		int[] L = new int[mid - left + 1];
		int[] R = new int[right - mid];
		
		//Populate arrays with the values on the left and right
		for(int i = 0; i < (mid - left + 1); i++){
			L[i] = arr[i + left];
		}
		for(int i = 0; i < (right - mid); i++){
			R[i] = arr[i + mid + 1];
		}
		
		//Set pointers and counters
		int i = left;
		int leftL = 0;
		int leftR = 0;
		int rightL = L.length;
		int rightR = R.length;
		
		//See which array(L or R) has the smaller value in front and insert into large array.
		while(rightL > leftL && rightR > leftR){
			if(L[leftL] < R[leftR]){
				arr[i] = L[leftL];	
				leftL++;
				i++;
			}
			else{
				arr[i] = R[leftR];
				leftR++;
				i++;
			}
		}
		if(leftL < rightL){
			while(leftL < rightL){
				arr[i] = L[leftL];
				leftL++;
				i++;
			}
		}
		if(leftR < rightR){
			while(leftR < rightR){
				arr[i] = R[leftR];
				leftR++;
				i++;
			}
		}
		return arr;
	}
}
