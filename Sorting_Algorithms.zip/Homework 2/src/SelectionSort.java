
public class SelectionSort extends SortingHelper{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printArray(selectionSort(ARR));
	}
	
	public static int[] selectionSort(int[] arr){
		for(int i = 0; i < arr.length; i++){
			//Swap the smallest unsorted index with the first unsorted value in the array.
			swap(arr, i, getIndexOfSmallest(arr, i, arr.length));
		}
		return arr;
	}
	
	public static int getIndexOfSmallest(int[] arr, int start, int end){
		int smallIndex = start;
		for(int i = start + 1; i < end; i++){
			//Find the minimum in the array and note its index
			if(arr[i] < arr[smallIndex]){
				smallIndex = i;
			}
		}
		return smallIndex;
	}

}
