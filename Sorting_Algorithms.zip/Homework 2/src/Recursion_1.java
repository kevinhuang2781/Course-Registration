
public class Recursion_1 {

	public static int[] arr = {3, 5, 2, 7, 2, 8, 2, 0};
	
	public static void main(String[] args) {
		System.out.println(findMax(arr, 0, arr.length - 1));

	}
	
	/**
	 * This method finds the maximum of an array using binary recursion.
	 * @param arr The array in question.
	 * @param start The beginning index of the array we are looking at.
	 * @param end The end index of the array we are looking at.
	 * @return The maximum
	 */
	public static int findMax(int[] arr, int start, int end){
		int max1;
		int max2;
		//Index of partition
		int mid = (start + end)/2;
		
		//When the array is partitioned so that its length is 1, we return that value.
		if(end == start){
			return arr[start];
		}
		
		//Call findMax on the left half of the array.
		max1 = findMax(arr, start, mid);
		
		//Call findMax on the right half of the array.
		max2 = findMax(arr, mid + 1, end);
		
		//After base case is reached, we pop the call from the stack and compare the two returned values from the previous call.
		//Return the larger out of the two, then compare that number with the next previous call.
		if(max1 > max2){
			return max1;
		}
		else{
			return max2;
		}
	}

}
