
public class InsertionSort extends SortingHelper{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printArray(insertionSort(ARR, 0, ARR.length));
	}
	
	public static int[] insertionSort(int[] arr, int start, int end){
		for(int i = start + 1; i < end; i++){
			int firstUnsorted = arr[i];
			insertInOrder(arr, firstUnsorted, start, i - 1);
		}
		return arr;
	}
	
	public static void insertInOrder(int[] arr, int firstUnsorted, int start, int end){
		int i = end;
		while(i >= start && firstUnsorted < arr[i]){
			//Move everything to the right
			arr[i+1] = arr[i];
			i--;
		}
		//Insert the value
		arr[i+1] = firstUnsorted;
	}

}
