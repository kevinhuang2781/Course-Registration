import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Execute app
 * @author kevinhuang
 *
 */
public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		
		Queue line = new Queue();
		
		Scanner reader;

		try{
			reader = new Scanner(new File(args[0]));
		}
		catch(FileNotFoundException e){
			reader = new Scanner(new File("src/" + args[0]));
		}

		/**
		 * Separate service time from customer data.
		 */
		boolean flag = true;
		
		/**
		 * Flag to check if we are leaving from the service time so that we can rid all the blank lines.
		 */
		boolean flag2 = true;
		
		/**
		 * Global variable to track reader.nextline() without actually calling the next line.
		 */
		String s = "";
		
		/**
		 * If we hit the last guy before store closes, flag it.
		 */
		boolean hitLast = false;
		while(reader.hasNextLine()){
			if(flag){
				s = reader.nextLine();
				int serviceTime = Integer.parseInt(s);
				Customer.setServiceTime(serviceTime);
				s = reader.nextLine();
				
				while(s.isEmpty()){
					s = reader.nextLine();
				}
				flag = false;
			}
			else{
				if(flag2){
					flag2 = false;
				}
				else{
					s = reader.nextLine();
				}
				String[] t = s.split("ID-NUMBER:");
				int ID = Integer.parseInt(t[1].trim());
				
				String x = reader.nextLine().trim();
				String[] y = x.split("ARRIVAL-TIME:");
				String aTime = y[1].trim();
				
				if(reader.hasNextLine()){
					reader.nextLine();
				}
				
				Customer customer = new Customer(ID, aTime);
				
				//Remove customers that have finished their service.
				if(line.hasTemp()){
					if(line.hasNext(Customer.getTemp())){
						if(line.isDoneServing(Customer.getTemp())){		
							line.setTime(Customer.getTemp().getATime() + Customer.getTemp().getWaitTime() + Customer.getServiceTime());
							line.leave();
						}
						else{
						}
						}
					else if(line.isDoneServing(Customer.getTemp(), Customer.convertToSeconds(aTime))){		
							line.setTime(Customer.getTemp().getATime() + Customer.getTemp().getWaitTime() + Customer.getServiceTime());
							line.leave();
					}
					
				}
				
				//Note previous time as the last time.
				line.setPreviousTime(line.getTime());

				line.arrive(customer);
				
				//Check if store is closed or not.
				if(line.hasTemp()){
					if(line.isClosed(Customer.getTemp())){	
						line.reduceCustomersServed();
						hitLast = true;
						line.setTime(Customer.getTemp().getATime() + Customer.getTemp().getWaitTime() + Customer.getServiceTime());			
					}
				}		
				
				//If the customer is early, store is closed
				if(customer.isEarly()){
					line.setOpen(false);
				}
				
				//If store was closed but next customer's arrival time is past 9, we open the store.
				if(customer.getATime() >= Customer.convertToSeconds("9:0:0") && !line.isOpen()){
					line.setPreviousTime(Customer.convertToSeconds("9:0:0"));
					line.reduceCustomersServed();
					line.setOpen(true);
				}
				
				//Serve the customers
				line.serve(customer);
			}
		}
		
		reader.close();

		//If we had already hit the last guy by this point, everyone leaves.
		if(hitLast){
			while(line.hasFirst()){
				line.leave();
			}
		}
		
		//If not, continue status quo
		while(line.hasFirst()){
			if(line.hasTemp()){
				if(line.hasNext(line.getFirst())){
					if(line.isClosed(Customer.getTemp())){	
						while(line.getFirst() != null){
							line.leave();
						}
						line.addCustomersServed();
					}
					else if(line.isDoneServing(Customer.getTemp(), line.getFirst().next().getATime())){		
						line.setTime(Customer.getTemp().getATime() + Customer.getTemp().getWaitTime() + Customer.getServiceTime());
					}
					
				}
				else{
					line.reduceCustomersServed();
					line.leave();
				}
				
			}
			if(line.hasFirst()){
				System.out.println("final break");
				line.serve(line.getFirst());
			}
		}
		
		//Read and handle queries. Send to Menu class
		Scanner queryReader;
		try{
			queryReader = new Scanner(new File(args[1]));
		}
		catch(FileNotFoundException e){
			queryReader = new Scanner(new File("src/" + args[1]));
		}
		
		PrintWriter writer = null;
		try {
			writer = new PrintWriter("results.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		while(queryReader.hasNextLine()){
			String f = queryReader.nextLine();
			if(f.contains(" ")){
				String[] t = f.split("\\s+");
				System.out.println(Menu.handleQuery(t[0], line, t[1]));
				writer.println(Menu.handleQuery(t[0], line, t[1]));
			}
			else{
				System.out.println(Menu.handleQuery(f, line));
				writer.println(Menu.handleQuery(f, line));
			}
		}
		writer.close();
		
		queryReader.close();
	}
	
}
