/**
 * This is essentially the class Node. It represents each individual customer within the queue.
 * @author kevinhuang
 */
public class Customer {

	/**
	 * Customers have and ID
	 */
	private int ID;
	
	/**
	 * The arrival time
	 */
	private int aTime;
	
	/**
	 * The service time constant
	 */
	private static int serviceTime;
	
	/**
	 * Customer's wait time. Initially 0.
	 */
	private int waitTime = 0;
	
	/**
	 * Pointer to the next customer.
	 */
	private Customer next;
	
	/**
	 * Temporary customer to store the customer at the front that is being serviced.
	 */
	private static Customer temp = null;
	
	/**
	 * Constructor
	 * @param ID 
	 * @param aTime
	 */
	public Customer(int ID, String aTime){
		this.ID = ID;
		this.aTime = Customer.convertToSeconds(aTime); //Convert from xx:xx:xx to secondss
	}
	
	/**
	 * Traverse through queue
	 * @return
	 */
	public Customer next(){
		return this.next;
	}
	
	/**
	 * Setter for next
	 * @param next
	 */
	public void setNext(Customer next){
		this.next = next;
	}
	
	
	/**
	 * Setter for serviceTime
	 * @param serviceTime
	 */
	public static void setServiceTime(int serviceTime){
		Customer.serviceTime = serviceTime;
	}
	
	/**
	 * Getter for waitTime
	 * @return waitTime
	 */
	public int getWaitTime(){
		return this.waitTime;
	}
	
	/**
	 * Add wait time to the customer
	 * @param waitTime
	 */
	public void addWaitTime(int waitTime){
		this.waitTime += waitTime;
	}
	
	/**
	 * Convert from "xx:xx:xx" to seconds
	 * @param aTime 
	 * @return seconds
	 */
	public static int convertToSeconds(String time){
		String[] x = time.split(":");
		int hour = Integer.parseInt(x[0]);
		int minute = Integer.parseInt(x[1]);
		int second = Integer.parseInt(x[2]);
		if(hour >= 1 && hour < 7){
			hour += 12;
		}
		return hour * 3600 + minute * 60 + second;
	}
	
	/**
	 * Check if the customer is early or not.
	 * @return
	 */
	public boolean isEarly(){
		return (this.aTime < convertToSeconds("9:0:0"));
	}
	
	/**
	 * Getter for Customer ID
	 * @return ID
	 */
	public int getID(){
		return this.ID;
	}

	/**
	 * Get the arrival time of a specific customer
	 * @return aTime
	 */
	public int getATime(){
		return this.aTime;
	}
	
	/**
	 * Return the service time constant
	 * @return serviceTime
	 */
	public static int getServiceTime(){
		return Customer.serviceTime;
	}

	/**
	 * Setter for a customer's wait time
	 * @param time 
	 */
	public void setWaitTime(int time){
		this.waitTime = time;
	}
	
	/**
	 * Create a copy of the person being served before he is removed from the queue
	 * @param customer
	 */
	public static void createTemp(Customer customer){
		Customer.temp = customer;
	}
	
	/**
	 * Retrieve the temporary customer
	 * @return temp
	 */
	public static Customer getTemp(){
		return Customer.temp;
	}

}
