import java.util.ArrayList;

/**
 * The class Queue is a more specific form of the linked list. It emulates the line customers must wait in before they get serviced.
 * For my queue, the person being serviced remains at the front of the queue until he is done being serviced.
 * @author kevinhuang
 */
public class Queue extends LinkedList{
	
	/**
	 * Array List that stores all removed customers so we can still access their attributes later on.
	 */
	private ArrayList<Customer> removedCustomers = new ArrayList<Customer>();
	
	/**
	 * The current time of day in seconds.
	 */
	private int time = Customer.convertToSeconds("9:0:0");
	
	/**
	 * The amount of customers served on a given day.
	 */
	private int customersServed;
	
	/**
	 * Note the longest break length.
	 */
	private int maxBreak = 0;
	
	/**
	 * Tracks all break lengths.
	 */
	private int breakLength = 0;
	
	/**
	 * The summation of all of the breaks.
	 */
	private int totalIdleTime = 0;
	
	/**
	 * A flag for whether or not the store is open yet.
	 */
	private boolean open = true;
	
	/**
	 * If the variable time is too fast and forgets to note some important times, previous time takes the role
	 * of maintaining the older time so we can access both.
	 */
	private int previousTime = 0;
	
	/**
	 * The amount of people in the queue.
	 */
	private int peopleInQueue = 0;
	
	/**
	 * The maximum amount of people in the queue.
	 */
	private int maxInQueue = 0;
	
	/**
	 * The time it takes to serve the customers.
	 */
	private int servingTime = 0;

	
	/**
	 * Calls the constructor of Linked List.
	 */
	public Queue(){
		super();
	}
	
	/**
	 * Getter for the time.
	 * @return time
	 */
	public int getTime(){
		return this.time;
	}
	
	/**
	 * Checks if the temporary customer exists
	 * @return if he exists
	 */
	public boolean hasTemp(){
		return (Customer.getTemp() != null);
	}
	
	/**
	 * Method for the WAIT-TIME-OF query
	 * @param ID
	 * @return the customer's wait time or -1 if no such customer exists.
	 */
	public int waitTimeOf(int ID){
		for(int i = 0; i < this.removedCustomers.size(); i++){
			if(this.removedCustomers.get(i).getID() == ID){
				return removedCustomers.get(i).getWaitTime();
			}
		}
		return -1;
	}
	
	/**
	 * Method for the NUMBER-OF-CUSTOMERS-SERVED query
	 * @return customersServed
	 */
	public int numberOfCustomersServed(){
		return this.customersServed;
	}
	
	/**
	 * Method for the LONGEST-BREAK-LENGTH query
	 * @return maxBreak
	 */
	public int longestBreakLength(){
		return this.maxBreak;
	}
	
	/**
	 * Method for the TOTAL-IDLE-TIME query
	 * @return totalIdleTime
	 */
	public int totalIdleTime(){
		return this.totalIdleTime;
	}
	
	/**
	 * Method for the MAXIMUM-NUMBER-OF-PEOPLE-IN-QUEUE-AT-ANY-TIME query
	 * @return maxInQueue
	 */
	public int maxInQueue(){
		return this.maxInQueue;
	}
	
	/**
	 * Setter for time
	 * @param time
	 */
	public void setTime(int time){
		this.time = time;
	}
	
	/**
	 * Checks if a customer is ready to be served. Time must be within store hours and customer has to be at the front of the line.
	 * @param customer
	 * @return if customer is ready to be served
	 */
	public boolean isReadyToServe(Customer customer){
		if(this.time >= Customer.convertToSeconds("9:0:0") && this.time < Customer.convertToSeconds("5:0:0")){
			return (customer == this.getFirst());
		}
		return false;
	}

	
	/**
	 * The serve method that updates all of the customer's attributes while serving a customer.
	 * @param customer
	 */
	public void serve(Customer customer){
		if(isReadyToServe(this.getFirst())){	
			//If the previous time is less than the arrival time of the first customer, 
			//there is a period where no customers arrive or a break.
			if(this.previousTime < this.getFirst().getATime()){
				
				this.servingTime = this.getFirst().getATime();

				this.peopleInQueue--;
				
				if(this.peopleInQueue > this.maxInQueue){
					this.maxInQueue = this.peopleInQueue;
				}
				this.peopleInQueue = 0;
				
				this.breakLength = this.getFirst().getATime() - this.previousTime;
				this.totalIdleTime += this.breakLength;
				if(this.breakLength > this.maxBreak){
					this.maxBreak = this.breakLength;
				}
				this.previousTime = this.getFirst().getATime();
				
			}
			this.customersServed++;
			this.getFirst().addWaitTime(this.previousTime - this.getFirst().getATime());
			//Store the data of the first customer before he is removed
			Customer.createTemp(this.getFirst());
		}
		
	}
	
	/**
	 * Check if a customer has finished his servicing.
	 * @param customer
	 * @return if the customer is done
	 */
	public boolean isDoneServing(Customer customer){
		return (customer.getATime() + customer.getWaitTime() + Customer.getServiceTime() >= this.previousTime);
	}
	
	/**
	 * Overloaded method that also takes into account the arrival time of the next customer to determine
	 * whether or not to remove the customer in question.
	 * @param customer
	 * @param aTime
	 * @return if the customer is done before the arrival of the next customer
	 */
	public boolean isDoneServing(Customer customer, int aTime){
		int nextTime = aTime;
		return(customer.getATime() + customer.getWaitTime() + Customer.getServiceTime() <= nextTime);
	}
	
	/**
	 * When a customer shows up, they are added to the queue.
	 * We not their arrival time
	 * @param customer
	 */
	public void arrive(Customer customer){
		this.addLast(customer);
		this.time = customer.getATime();
	}

	/**
	 * Method for when a customer has finished being serviced and must be removed from the queue.
	 */
	public void leave(){
		try {
			this.peopleInQueue++;
			if(this.getFirst().next() != null){
				if(this.servingTime == this.getFirst().next().getATime()){
					this.peopleInQueue++;
					System.out.println("reach");
				}
			}
			this.removedCustomers.add(removeFirst());
		} catch (NullListException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Setter for open boolean
	 * @param open
	 */
	public void setOpen(boolean open){
		this.open = open;
	}
	
	/**
	 * Getter for open boolean
	 * @return
	 */
	public boolean isOpen(){
		return this.open;
	}
	
	/**
	 * Setter for previous time
	 * @param time
	 */
	public void setPreviousTime(int time){
		this.previousTime = time;
	}
	
	/**
	 * Decrement customers served
	 */
	public void reduceCustomersServed(){
		this.customersServed--;
	}
	
	/**
	 * Increment customers served
	 */
	public void addCustomersServed(){
		this.customersServed++;
	}
	
	/**
	 * Checks if the store is closed after servicing the last customer.
	 * @param customer
	 * @return if the store is closed or not.
	 */
	public boolean isClosed(Customer customer){
		return (customer.getATime() + customer.getWaitTime() + Customer.getServiceTime() >= Customer.convertToSeconds("5:0:0"));
	}
}
