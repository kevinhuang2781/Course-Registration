import java.io.File;
import java.util.Scanner;

/**
 * Handles all queries.
 * @author kevinhuang
 *
 */
public class Menu {
	

	/**
	 * Handle all of the queries except WAITING-TIME-OF.
	 * Send to methods in Queue class.
	 * @param query
	 * @param line
	 */
	public static String handleQuery(String query, Queue line){
		switch(query){
			case "NUMBER-OF-CUSTOMERS-SERVED": return ("NUMBER-OF-CUSTOMERS-SERVED: " + line.numberOfCustomersServed());
			case "LONGEST-BREAK-LENGTH": return ("LONGEST-BREAK-LENGTH: " + line.longestBreakLength());
			case "TOTAL-IDLE-TIME": return ("TOTAL-IDLE-TIME: " + line.totalIdleTime());
			case "MAXIMUM-NUMBER-OF-PEOPLE-IN-QUEUE-AT-ANY-TIME": return ("MAXIMUM-NUMBER-OF-PEOPLE-IN-QUEUE-AT-ANY-TIME: " + line.maxInQueue());
			default: return ("There is an invalid query in the file.");
		}
	}
	
	/**
	 * Since WAITING-TIME-OF must read an ID, it is in its own overloaded method.
	 * @param query
	 * @param line
	 * @param ID
	 */
	public static String handleQuery(String query, Queue line, String ID){
		int custID = Integer.parseInt(ID);
		switch(query){
			case "WAITING-TIME-OF": return ("WAITING-TIME-OF " + ID + ": " + line.waitTimeOf(custID));
			 default: return ("There is an invalid query in the file.");
		}
		
	}

}
