
public class NullListException extends Throwable{

	public NullListException(){};
}
