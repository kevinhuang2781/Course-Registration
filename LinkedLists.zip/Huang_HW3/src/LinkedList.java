/**
 * This is the Linked List class that is the parent to the queue.
 * It incluldes all the general methods for the linked list data structure.
 * @author kevinhuang
 */
public class LinkedList{

	/**
	 * Reference to the first node or first customer in the queue.
	 */
	private Customer first;

	/**
	 * Keeps track of the size of the linked list.
	 */
	private int size;
	
	/**
	 * Constructor. Initially list will be empty.
	 */
	public LinkedList(){
		first = null;
		size = 0;
	}
	
	/**
	 * In a queue, it is first in first out. Therefore we can only add customers to the end of the list.
	 * @param customer
	 */
	public void addLast(Customer customer){
		Customer position = first;
		Customer newCustomer = customer;
		if(this.size == 0){
			first = newCustomer;
		}
		else if(this.size == 1){
			first.setNext(newCustomer);
		}
		else{
			while(position.next() != null){
				position = position.next();
			}
			position.setNext(newCustomer);
			position = first;
		}
		this.size++;
	}
	
	/**
	 * In a queue, it is first in first out. Therefore we can only remove customers at the front of the list.
	 * @return
	 * @throws NullListException
	 */
	public Customer removeFirst() throws NullListException{
		if(this.size == 0){
			throw new NullListException();
		}

		else{
			Customer temp = this.first;
			this.first = this.first.next();
			this.size--;
			return temp;
		}	
		
	}
	
	/**
	 * Getter for the size of the list.
	 * @return size
	 */
	public int getSize(){
		return this.size;
	}
	
	/**
	 * Getter for the first element of the list
	 * @return first
	 */
	public Customer getFirst(){
		return this.first;
	}
	
	/**
	 * Checks if the first element exists
	 * @return
	 */
	public boolean hasFirst(){
		return (first != null);
	}

	/**
	 * Checks if a node has a next element
	 * @param customer
	 * @return if customer.next is null
	 */
	public boolean hasNext(Customer customer){
		return (customer.next() != null);
	}
}
